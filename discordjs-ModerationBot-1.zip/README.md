# discord.js-ModerationBot
ModerationBot V1 is a simple moderation bot with all basics commands that a bot needs!! This is the First version of this bot and the bot gets updated with new version every month!! So make sure to follow me on **[GitHub](https://github.com/drstrangegithub)** for latest updates!!

# Setup
Import the project into repl.it and then fill out your bot token in config.js file.. Then type npm install in the console and let repl.it install all the packages..
Next after everything is complete run the bot and the bot will come online!! Yes, it's that easy!!

# Video setup guide
Check out this **[Video](https://www.youtube.com/channel/UCmTSEzt4h1S4MiCM1grWu9g)**
And if you want more easy bot tutorials Subscribe to the **[CHANNEL](https://www.youtube.com/channel/UCmTSEzt4h1S4MiCM1grWu9g)** it will support me a lot!!

**Thanks for Choosing MODERATION.V1**
