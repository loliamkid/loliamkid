exports.Prefix = `!`;
exports.Token = `ODc2MDY1NTUxOTI2MDY3MjIx.YRepoA.3HYZ_F3qAaj-BbRYGJZeNvL2ByA`;
exports.Color = `RANDOM`;
